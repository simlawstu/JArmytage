/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tripbooking.Classes;

import java.util.ArrayList;

/**
 *
 * @author jasmi
 */
public class Data {
    public static ArrayList<Student> students;
    public static ArrayList<Booking> bookings;
    public static ArrayList<Trip> trips;
    
}
